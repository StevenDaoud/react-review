import React, { Component } from 'react';
import Axios from "axios";

class Nav extends Component {
    
    constructor(){
        super();
        this.state = {
            counter : 0,
            isReady : false,
            data: []
        }
    }

    componentDidMount(){
        console.log("COMPONENT DID MOUNT")
    }

    componentWillReceiveProps(){
        this.setState({
            counter : this.state.counter + 1
        })

        console.log("I WILL RECIEVE PROPS!")
    }

    componentWillMount(){
        Axios.get("https://api.fda.gov/drug/event.json?api_key=1NEZVMyk7eyjniwNIePgVcgnuqu5RfAcRhjNfSLD&search=tacos").then((data)=>{
    
            this.setState({
                isReady : true,
                data : data.data.results[0].patient.drug
            }, function(){
                console.log('SET STATE HAS COMPLETED')
            });

            console.log(this.state.data)
        })
    }
    

    render() {
        return (
        <nav>

            {this.state.isReady ? 

                this.state.data.map((item)=>{
                    return <div key={Math.round(Math.random() * 900000)}>
                    {item.medicinalproduct}
                    </div>
                })  

            : "SAD"}
            {/* <ul>
    
                <img alt="" src={this.props.logo}/>
                <li><a href="/">Taco {this.state.counter}</a></li>
                <li>Taco 2</li>
                <li>Taco 3</li>
            </ul> */}
        </nav>
        );
    }
}

export default Nav;
